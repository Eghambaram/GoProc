This file was placed here as part of creating a new folder. 
Since empty folders in projects are hidden by default, this file 
allowed the folder to be initially visible. Once the folder has 
additional files this readme.txt is no longer necessary and can be deleted.

You can avoid creation of the readme.txt file in the future by 
configuring the Applications window to display empty folders. 
To do so, enable the "Show Empty Folders" setting on the 
display options of the Projects pane.
